import React from 'react';
// import logo from './logo.svg';
import CustomNav from './components/CustomNav';
import Login from './components/Login';
import Home from './components/Home';
import AdminDashboard from './Component/Admin/AdminDashboard';
import AddFood from './components/Admin/AddFood';
import Dashboard from './components/Dashboard';
import PrivateRoute from './components/PrivateRoute';


import Signup from './components/Signup';
import { BrowserRouter, Route, Switch } from 'react-router-dom';
import './App.css';

function App() {
  return (
    
   <div>
   
  <BrowserRouter>
  <CustomNav/>
  <Switch>
 
    <Route exact path='/' component={Home}/>
    <Route path='/login' component={Login}/>
    <Route path='/signup' component={Signup}/>
    <PrivateRoute path='/dashboard' component={Dashboard}/>
    <PrivateRoute path='/admin'component={AdminDashboard}/>
    <PrivateRoute path='/addfood' component={AddFood}/>

  </Switch>
  </BrowserRouter>

   </div>
   

  );
}

export default App;
