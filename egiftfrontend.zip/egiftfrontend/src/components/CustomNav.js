import React, { useState } from 'react';
import {
  Collapse,
  Navbar,
  NavbarToggler,
  NavbarBrand,
  Nav,
  NavItem,
  Button,
  NavLink

  
} from 'reactstrap';


const Example = (props) => {

  
  const [isOpen, setIsOpen] = useState(false);

  const toggle = () => setIsOpen(!isOpen);

  return (
    <div>
      <Navbar color="light" light expand="md">
        <NavbarBrand href="/">E-gift Cards</NavbarBrand>
        <NavbarToggler onClick={toggle} />
        <Collapse isOpen={isOpen} navbar>
          <Nav className="mr-auto" navbar>
            <NavItem>
              <NavLink href="/">Home</NavLink>
            </NavItem>
            <NavItem>
              <NavLink href="/gifts">Gifts</NavLink>
            </NavItem>
            <NavItem>
              <NavLink href="/about">About</NavLink>
            </NavItem>
          </Nav>
          <NavItem>
              <Button href="/login" onClick="{this.handleOpen}" outline color="primary">Login</Button> 
          </NavItem>
         
          <NavItem>
             <Button href="signup" outline color="primary">Signup</Button>
          </NavItem>
        </Collapse>
      </Navbar>
    </div>
  );
}

export default Example;