import React, { Component } from 'react'
import Footer from './Footer/Adminfooter';

import AdminNavbar from './Header/AdminNavbar';


export default class AdminDashboard extends Component {
    render() {
        return (
            <div>

                <AdminNavbar />
                
            </div>
        )
    }
}
