const mongoose = require("mongoose");


const requestSchema= new mongoose.Schema(
    {
        giftid:
        {
            type: mongoose.Schema.Types.ObjectId,
            ref: 'Gifts'
        },
        sender:{
            type: mongoose.Schema.Types.ObjectId,
            ref: 'User'
        },
        giftCode:
        {
            type: String,
            required: true
        },
        used: {
            type: Boolean,
            default: false
        }

    }
)

module.exports=mongoose.model('Request',requestSchema);