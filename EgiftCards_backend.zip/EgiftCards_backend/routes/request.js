const express=require('express');
var crypto=require('crypto');

const RequestModel = require('../models/request');
const router = express.Router();

const random=require('../random.js');

router.route('/')
.get((req,res,next)=>{
    RequestModel.find({used:true})
        .populate({'path':'sender'})
        .populate({'path':'giftid'})
        .then((request) => {
            res.json(request);
        }).catch(next);
})
.post((req, res, next) => {
    const giftcode = crypto.randomBytes(Math.ceil(12/2)).toString('hex').slice(0,12);

    RequestModel.create({
        giftid: req.body.giftid,
        sender: req.body.sender,
        used: true,
        giftCode: giftcode
    })
    .then((requestModel)=>{
        res.status=200;
        res.json(requestModel);
    })
    .catch((err) => next(err))
});


router.route('/:id')
.get((req,res,next)=>{
    RequestModel.findById(req.params.id)
        .populate({'path':'sender'})
        .populate({'path':'giftid'})
        .then((request) => {
            res.json(request);
        }).catch(next);
});

module.exports = router;