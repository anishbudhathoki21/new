const express=require('express');
const Gift=require('../models/gift');
const auth=require('../auth');
const crypto=require('crypto');
const random=require('../random.js');
const router = express.Router();



router.route('/')
 
.get((req,res,next)=>{
    Gift.find({})
    .then((gift)=>{
        status=200;
        res.json(gift);

    })
    .catch((err)=>next(err));

})

.post((req,res,next)=>{
    Gift.create({
        giftName: req.body.giftName,
        giftPrice: req.body.giftPrice,
        giftPic: req.body.giftPic,
        // giftCode: randomBytes
    })
    .then((gift)=>{
        res.status=200;
        res.json(gift);
    })
    .catch((err) => next(err));
})
.put((req,res,next)=>{
    res.statusCode=201;
    res.json("You cannot update gift");

})

.delete((req,res,next)=>{
    Gift.deleteMany({})
    .then((gift)=>{
        res.json(gift);

    })
});


 router.route('/:id')
  .get((req,res,next)=>{
    Gift.findById(req.params.id)
     .then((gift)=>{
        res.json(gift);
     })
     .catch((err) => next(err));
 })
 .post((req,res,next)=>{
     res.statusCode=201;
     res.json("You cannot add gift on here");
 })


 .put((req,res,next)=>{
     Gift.findByIdAndUpdate(req.params.id,{$set : req.body},{new:true})
     .then((gift)=>{
         res.json(gift);

     })
     .catch((err)=> next(err));
 })

 

 .delete((req,res,next)=>{
     Gift.findByIdAndDelete(req.params.id)
     .then((gift)=>{
         res.json(gift);
     })
     .catch((err)=> next(err));
 })

module.exports= router;


