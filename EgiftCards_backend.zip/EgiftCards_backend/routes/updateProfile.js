const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/users');
const auth = require('../auth');
const router = express.Router();
router.put('/updateProfile', auth.verifyUser, (req, res, next) => {
    User.findByIdAndUpdate(req.user._id, { $set: {username:req.body.username, fullname: req.body.fullname, email: req.body.email, contact:req.body.contact,image:req.body.imgProfile} }, { new: true })
    .then((user) => {
        res.json({ _id: user._id, fullname: req.user.fullname, username: req.user.username, contact: req.user.contact,email:req.user.email,imgProfile:req.user.image});
    }).catch(next);
});
router.get('/retreiveProfile',auth.verifyUser,(req,res,next)=>
{
    User.findById(req.user._id)
    .then((user)=>
    {
        res.json({ _id: user._id, fullname: req.user.fullname, username: req.user.username, contact: req.user.contact,email:req.user.email,imgProfile:req.user.image});
    })
    .catch(next);
});
router.post('/verifyPassword', auth.verifyUser, (req, res, next) => {
    User.findById(req.user._id)
        .then((user)=>{
            bcrypt.compare(req.body.password, user.password)
                    .then((isMatch) => {
                        if(!isMatch){
                            let err = new Error('Password does not match!');
                            err.status = 401;
                            return next(err);
                        }
                        res.json({status: 'ok', password: req.user.password});
                    }).catch(next);
        }).catch(next);
});

router.put('/updatePassword', auth.verifyUser, (req, res, next) => {
        let password = req.body.password;
        bcrypt.hash(password, 10, function (err, hash){
            if(err){
                throw new Error('Could not hash!');
            }
            else{
                password = hash;
            }

        User.findByIdAndUpdate(req.user._id, {$set:{password:password}}, {new: true})
        .then((user)=>{
            res.json({status: 'ok', password: req.user.password});
        }).catch(next);
    });
});

module.exports= router;