const crypto = require('crypto');
const express=require('express');
const random=require('./module.js');
var app=express();

app.get('/',function(req,res)
{
    crypto.randomBytes(20,(err,buf)=>
    {
        var randomValue=buf.toString('hex');
        res.send(`Random Characters:" ${random.RandomChar(40)} <br> Crypto ${randomValue}`);
    })
   

});

app.listen(3001,function()
{
Console.log("Running on port 3001");
});
