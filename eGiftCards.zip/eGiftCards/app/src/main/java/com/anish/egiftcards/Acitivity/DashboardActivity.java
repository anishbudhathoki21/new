package com.anish.egiftcards.Acitivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.anish.egiftcards.API.EgiftAPI;
import com.anish.egiftcards.Fragment.HomeFragment;
import com.anish.egiftcards.Fragment.ProfileFragment;
import com.anish.egiftcards.Fragment.SearchFragment;
import com.anish.egiftcards.Model.User;
import com.anish.egiftcards.R;
import com.anish.egiftcards.Url;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    public static User globalUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener(navListener);
        loaduser();
        getSupportFragmentManager().beginTransaction().replace(R.id.main_frame,new HomeFragment()).commit();

    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener= new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
           Fragment selectedFragment=null;

           switch(menuItem.getItemId())
           {
               case R.id.action_home:
                   selectedFragment= new HomeFragment();
                    break;
               case R.id.search:
                   selectedFragment= new SearchFragment();
                   break;

               case R.id.profile:
                   selectedFragment= new ProfileFragment();
                   break;


           }
           getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, selectedFragment).commit();
           return true;
        }
    };

    public void loaduser(){
            EgiftAPI userAPI= Url.getInstance().create(EgiftAPI.class);
            Call<User> userModelCall = userAPI.retrievUserdetail(Url.token);

            userModelCall.enqueue(new Callback<User>() {
                @Override
                public void onResponse(Call<User> call, Response<User> response) {
                    if(!response.isSuccessful()){
                        Toast.makeText(getApplicationContext(),"Code"+response.code(),Toast.LENGTH_LONG).show();
                        return;
                    }
                    globalUser = response.body();

                    String fullname=response.body().getFullname();
                    String email =response.body().getEmail();
                    String contact =response.body().getContact();
                    String username =response.body().getUsername();

                }

                @Override
                public void onFailure(Call<User> call, Throwable t) {

                }
            });

        }

}
