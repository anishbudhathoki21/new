package com.anish.egiftcards.API;

import com.anish.egiftcards.Model.Gift;
import com.anish.egiftcards.Model.GiftSend;
import com.anish.egiftcards.Model.User;
import com.anish.egiftcards.Model.UserResponse;
import com.anish.egiftcards.Model.imgResponse;
import com.anish.egiftcards.Model.updateUser;

import java.util.List;

import okhttp3.MultipartBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;

public interface EgiftAPI {

    @POST("users/signup")
    Call<Void> signup(@Body User user);

    @POST("users/login")
    Call<UserResponse> loginWithToken(@Body User user);

    @Multipart
    @POST("uploads/")
    Call<imgResponse> uploadImage(@Header("Authorization") String token, @Part MultipartBody.Part file);

    @GET("gift")
    Call<List<Gift>> getgifts();

    @POST("request")
    Call<GiftSend> giftSend (@Body GiftSend gifts);

    @GET("updateProfile/retreiveProfile")
    Call<User> retrievUserdetail(@Header("Authorization") String token);

    @PUT("updateProfile/updateProfile")
    Call<updateUser> updateProfile(@Header("Authorization") String token, @Body updateUser user);
//
//    @POST("users/verifyPassword")
//    Call<changePassword> checkPassword(@Header("Authorization") String token, @Body changePassword password);
//
//    @PUT("users/updatePassword")
//    Call<changePassword> changePassword (@Header("Authorization") String token, @Body changePassword password);
}
