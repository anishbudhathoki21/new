package com.anish.egiftcards.Model;

public class GiftSend {



    String _id, giftid, sender, giftcode;
    Boolean used;

    public GiftSend(String _id) {
        this._id = _id;
    }

    public GiftSend(String _id, String giftid, String sender, String giftcode, Boolean used) {
        this._id = _id;
        this.giftid = giftid;
        this.sender = sender;
        this.giftcode = giftcode;
        this.used = used;
    }

    public GiftSend(String giftid, String sender, Boolean used) {
        this.giftid = giftid;
        this.sender = sender;
        this.used = used;
    }

    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getGiftid() {
        return giftid;
    }

    public void setGiftid(String giftid) {
        this.giftid = giftid;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getGiftcode() {
        return giftcode;
    }

    public void setGiftcode(String giftcode) {
        this.giftcode = giftcode;
    }

    public Boolean getUsed() {
        return used;
    }

    public void setUsed(Boolean used) {
        this.used = used;
    }

    //    public String getGiftCode() {
//        return giftCode;
//    }
//
//    public void setGiftCode(String giftCode) {
//        this.giftCode = giftCode;
//    }
}
