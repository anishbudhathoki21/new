package com.anish.egiftcards.Model;

import com.anish.egiftcards.API.EgiftAPI;
import com.anish.egiftcards.Url;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Response;

public class LoginBLL {
    boolean isSuccess = false;

    public boolean checkUser(String username, String password) {

        User user = new User(username, password);
        EgiftAPI usersAPI = Url.getInstance().create(EgiftAPI.class);
        Call<UserResponse> usersCall = usersAPI.loginWithToken(user);

        try {
            Response<UserResponse> loginResponse = usersCall.execute();
            if (loginResponse.isSuccessful() &&
                    loginResponse.body().getStatus().equals("Login Successful")) {

                Url.token += loginResponse.body().getToken();
                // Url.Cookie = imageResponseResponse.headers().get("Set-Cookie");
                isSuccess = true;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return isSuccess;
    }
}
