package com.anish.egiftcards.Acitivity;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.anish.egiftcards.API.EgiftAPI;
import com.anish.egiftcards.Model.Gift;
import com.anish.egiftcards.Model.GiftSend;
import com.anish.egiftcards.R;
import com.anish.egiftcards.Url;
import com.squareup.picasso.Picasso;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BuyGiftActivity extends AppCompatActivity {
    ImageView imgGift;
    String id;
     Button btnSend;
    TextView giftName,giftPrice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buy_gift);
        final Executor executor= Executors.newSingleThreadExecutor();
        final BiometricPrompt biometricPrompt= new BiometricPrompt.Builder(this)
                .setTitle("Fingerprint Authentication")
                .setSubtitle("Gift")
                .setDescription("Are you sure want to send this gift? Place your fiinger to send")
                .setNegativeButton("Cancel", executor, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                }).build();

        imgGift=findViewById(R.id.imgGift);
        giftName=findViewById(R.id.tvGname);
        giftPrice=findViewById(R.id.tvGprice);
        btnSend=findViewById(R.id.btnSend);

        btnSend.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                giftSend();
            }
        });

        Bundle bundle=getIntent().getExtras();
        if(bundle!=null)
        {
                id=bundle.getString("id");
             giftName.setText(bundle.getString("giftName"));
            giftPrice.setText(bundle.getString("giftPrice"));

            String imgPath = Url.imagePath +  bundle.getString("giftImg").toString();

            Picasso.get().load(imgPath).into(imgGift);
        }
        else
        {
            Toast.makeText(this, "No message", Toast.LENGTH_SHORT).show();
        }


    }

    private void giftSend() {


        GiftSend gifts = new GiftSend(id, DashboardActivity.globalUser.get_id(), false);

        EgiftAPI egiftAPI = Url.getInstance().create(EgiftAPI.class);
        Call <GiftSend> giftCall = egiftAPI.giftSend(gifts);

        giftCall.enqueue(new Callback<GiftSend>() {
            @Override
            public void onResponse(Call<GiftSend> call, Response<GiftSend> response) {
                Toast.makeText(BuyGiftActivity.this, "Gift Sent!!!" ,Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onFailure(Call<GiftSend> call, Throwable t) {
                Toast.makeText(BuyGiftActivity.this, "Error" + t.getLocalizedMessage(),Toast.LENGTH_SHORT).show();

            }
        });


//
    }
}
