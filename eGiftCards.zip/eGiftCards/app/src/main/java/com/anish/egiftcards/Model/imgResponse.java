package com.anish.egiftcards.Model;

public class imgResponse {
    private String filename;

    public imgResponse(String filename){
        this.filename = filename;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }
}
