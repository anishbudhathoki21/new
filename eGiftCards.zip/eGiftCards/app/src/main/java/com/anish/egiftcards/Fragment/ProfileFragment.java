package com.anish.egiftcards.Fragment;


import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.loader.content.CursorLoader;

import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.anish.egiftcards.API.EgiftAPI;
import com.anish.egiftcards.Acitivity.MainActivity;
import com.anish.egiftcards.Model.StrictModeClass;
import com.anish.egiftcards.Model.User;
import com.anish.egiftcards.Model.imgResponse;
import com.anish.egiftcards.Model.updateUser;
import com.anish.egiftcards.R;
import com.anish.egiftcards.Url;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.IOException;

import de.hdodenhof.circleimageview.CircleImageView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;
import static com.anish.egiftcards.Url.imagePath;

/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragment extends Fragment {
    EditText username,fullname,contact,email;
    Button btnUpdate;
    SharedPreferences rememberMe;
    CircleImageView imgProfilePicPost;
    ImageView imgLogout;
    String imgPath, imageName;

    private static final int CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE = 200;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {



//        btnUpdate.setOnClickListener(this);
        // Inflate the layout for this fragment
        View v= inflater.inflate(R.layout.fragment_profile, container, false);
        username=v.findViewById(R.id.etUsername);
        fullname=v.findViewById(R.id.etFullname);
        email=v.findViewById(R.id.etEmail);
        contact=v.findViewById(R.id.etContact);
        imgProfilePicPost=v.findViewById(R.id.imgProfilePicPost);
        rememberMe = getActivity().getSharedPreferences("User", Context.MODE_PRIVATE);
        imgLogout=(ImageView)v.findViewById(R.id.imgLogout);
        btnUpdate = v.findViewById(R.id.btnUpdate);
        retreive();

        imgProfilePicPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImg();
            }
        });

        imgLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logout();
            }
        });

        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadFile();
                updateDetails();
            }
        });

        return v;


    }
    private void logout() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setCancelable(false);
        builder.setMessage("Do you want to Logout?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //if user pressed "yes", then he is allowed to exit from application
                rememberMe.edit().clear().commit();
                Intent login= new Intent(getActivity(), MainActivity.class);
                startActivity(login);
//                getActivity().finish();

            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //if user select "No", just cancel this dialog and continue with app
                dialog.cancel();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    public void retreive()
    {
        EgiftAPI egiftAPI= Url.getInstance().create(EgiftAPI.class);
        Call<User> userCall= egiftAPI.retrievUserdetail(Url.token);
        userCall.enqueue(new Callback<User>() {
            @Override
            public void onResponse(Call<User> call, Response<User> response) {
                if(!response.isSuccessful()){
                    Toast.makeText(getActivity(), "Error", Toast.LENGTH_SHORT).show();
                }
                username.setText(response.body().getUsername());
                fullname.setText(response.body().getFullname());
                email.setText(response.body().getEmail());
                contact.setText(response.body().getContact());
                String imagepath= imagePath + response.body().getImgProfile();
                System.out.println("The image response is:" + imagepath);
                Picasso.get().load(imagepath).into(imgProfilePicPost);
            }

            @Override
            public void onFailure(Call<User> call, Throwable t) {
                Toast.makeText(getActivity(), "Error"+t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void chooseImg(){
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == CAPTURE_IMAGE_ACTIVITY_REQUEST_CODE){
            if(resultCode==RESULT_OK && data!=null){
                Uri uri = data.getData();
                imgProfilePicPost.setImageURI(uri);
                imgPath = getPath(uri);
                System.out.println("The uri is "+uri);

            }
            else {
                Toast.makeText(getActivity(), "Image not selected", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(getActivity(), "Couldn't upload image", Toast.LENGTH_SHORT).show();
        }
    }

    private String getPath(Uri uri){
        String[] proj = {MediaStore.Images.Media.DATA};
        CursorLoader loader = new CursorLoader(getActivity().getApplicationContext(), uri, proj, null, null, null);

        Cursor cursor = loader.loadInBackground();
        int colIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String res = cursor.getString(colIndex);
        cursor.close();
        return res;
    }

    private void uploadFile(){
        if(imgPath!=null){
            File file = new File(imgPath);
            RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-data"), file);
            MultipartBody.Part body = MultipartBody.Part.createFormData("imageFile", file.getName(), requestBody);

            EgiftAPI imageApi = Url.getInstance().create(EgiftAPI.class);
            Call<imgResponse> imageResponseCall = imageApi.uploadImage(Url.token, body);

            StrictModeClass.StrictMode();

            try {
                Response<imgResponse> imageResponseResponse = imageResponseCall.execute();
                imageName = imageResponseResponse.body().getFilename();
            }catch (IOException e){
                Toast.makeText(getActivity(), "Error" + e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        }else {
            Toast.makeText(getActivity(), "Please choose file to update picture", Toast.LENGTH_SHORT).show();
        }

    }

    private void updateDetails(){
        if(imageName!=null){
            if(username.getText().toString() != null && fullname.getText().toString() != null && email.getText().toString() != null && contact.getText().toString()!=null){
                updateUser updateUsers = new updateUser(username.getText().toString(), fullname.getText().toString(), email.getText().toString(), contact.getText().toString(), imageName);
                EgiftAPI updateDetails = Url.getInstance().create(EgiftAPI.class);
                Call<updateUser> updateInfoCall = updateDetails.updateProfile(Url.token, updateUsers);

                updateInfoCall.enqueue(new Callback<updateUser>() {
                    @Override
                    public void onResponse(Call<updateUser> call, Response<updateUser> response) {
                        if(!response.isSuccessful()){
                            Toast.makeText(getActivity(), "Error : Failed to update info" , Toast.LENGTH_SHORT).show();
                        }

                        Toast.makeText(getActivity(), "Information updated successfully", Toast.LENGTH_SHORT).show();

                    }

                    @Override
                    public void onFailure(Call<updateUser> call, Throwable t) {
                        Toast.makeText(getActivity(), "Error : "+t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
            else {
                Toast.makeText(getActivity(), "Please fill all the fields.", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            if(username.getText().toString() != null && fullname.getText().toString() != null && email.getText().toString() != null && contact.getText().toString()!=null){
                updateUser updateUsers = new updateUser(username.getText().toString(), fullname.getText().toString(), email.getText().toString(), contact.getText().toString());
                EgiftAPI updateDetails = Url.getInstance().create(EgiftAPI.class);
                Call<updateUser> updateInfoCall = updateDetails.updateProfile(Url.token, updateUsers);

                updateInfoCall.enqueue(new Callback<updateUser>() {
                    @Override
                    public void onResponse(Call<updateUser> call, Response<updateUser> response) {
                        if(!response.isSuccessful()){
                            Toast.makeText(getActivity(), "Error : Failed to update info" , Toast.LENGTH_SHORT).show();
                        }

                        Toast.makeText(getActivity(), "Information updated successfully", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onFailure(Call<updateUser> call, Throwable t) {
                        Toast.makeText(getActivity(), "Error : "+t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
            else {
                Toast.makeText(getActivity(), "Please fill all the fields.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
