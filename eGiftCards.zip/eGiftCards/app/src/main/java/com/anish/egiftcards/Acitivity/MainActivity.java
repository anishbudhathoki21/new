package com.anish.egiftcards.Acitivity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Notification;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.anish.egiftcards.API.EgiftAPI;
import com.anish.egiftcards.Model.LoginBLL;
import com.anish.egiftcards.Model.StrictModeClass;
import com.anish.egiftcards.Model.User;
import com.anish.egiftcards.R;
import com.anish.egiftcards.Url;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    Button btnLogin;
    EditText username, password;
    TextView tvSign;
    SharedPreferences rememberMe;
    CheckBox chkRemember;
    Vibrator vibratorSensor;
    NotificationManagerCompat notificationManagerCompat;
    TextView ProximitySensor;
    SensorManager mySensorManager;
    Sensor myProximitySensor;

    BroadCast broadcast;

    int a;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        broadcast = new BroadCast();
        notificationManagerCompat = NotificationManagerCompat.from(this);
        Channel channel = new Channel(this);
        channel.createChannel();

        displayNotification1();

        rememberMe = getSharedPreferences("User", Context.MODE_PRIVATE);
        username = (EditText)findViewById(R.id.etUsername);
        password = (EditText)findViewById(R.id.etPassword);
        btnLogin = (Button)findViewById(R.id.btnLogin);


        vibratorSensor=(Vibrator)getSystemService(VIBRATOR_SERVICE);
        chkRemember=(CheckBox)findViewById(R.id.chkShared) ;
        tvSign=(TextView)findViewById(R.id.tvSign);

        if (rememberMe.getString("username", "").isEmpty()) {
            username.setText("");
            password.setText("");
            chkRemember.setChecked(false);
        } else {
            username.setText(rememberMe.getString("username", ""));
            password.setText(rememberMe.getString("password", ""));
            chkRemember.setChecked(true);

        }

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        tvSign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signUp();
            }
        });



    }

        private void login()
        {
            String uname = username.getText().toString();
            String pass = password.getText().toString();


            LoginBLL loginBLL = new LoginBLL();

            StrictModeClass.StrictMode();
            if (loginBLL.checkUser(uname, pass)) {
                Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                startActivity(intent);
                finish();
            } else {
                vibratorSensor.vibrate(1000);
                Toast.makeText(this, "Either username or password is incorrect", Toast.LENGTH_SHORT).show();
                username.requestFocus();
            }
            if (chkRemember.isChecked()) {
                SharedPreferences.Editor editor = rememberMe.edit();

                editor.putString("username", uname);
                editor.putString("password", pass);

                editor.commit();
            } else {
                rememberMe.edit().clear().commit();
            }


        }



        public void signUp()
        {
            Intent sign= new Intent(this,SignupActivity.class);
            startActivity(sign);
        }

    private void displayNotification1() {

        Notification notification = new NotificationCompat.Builder(this, Channel.channel_2)
                .setSmallIcon(R.drawable.wifi_working)
                .setContentTitle("Connected")
                .setContentText("Internet is working")
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .build();

        notificationManagerCompat.notify(1, notification);


    }

    private void displayNotification2() {
        Notification notification = new NotificationCompat.Builder(this, Channel.channel_1)
                .setSmallIcon(R.drawable.wifi_notworking)
                .setContentTitle("Disconnected")
                .setContentText("Internet is not working")
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .build();

        notificationManagerCompat.notify(2, notification);

    }
    @Override
    protected void onStart() {
        super.onStart();

        IntentFilter intentFilter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(broadcast,intentFilter);

    }

    @Override
    protected void onStop() {
        super.onStop();

        unregisterReceiver(broadcast);
    }


}



