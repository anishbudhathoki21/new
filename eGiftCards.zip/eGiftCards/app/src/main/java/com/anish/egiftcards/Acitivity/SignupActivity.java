package com.anish.egiftcards.Acitivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.anish.egiftcards.API.EgiftAPI;
import com.anish.egiftcards.Model.User;
import com.anish.egiftcards.R;
import com.anish.egiftcards.Url;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupActivity extends AppCompatActivity {

    EditText Fullname, Email,Username, Password, Contact;
    Button btnSignup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        Username=findViewById(R.id.etUsername);
        Password=findViewById(R.id.etPassword);
        Fullname=findViewById(R.id.etFullname);
        Email=findViewById(R.id.etEmail);
        Contact=findViewById(R.id.etContact);
        btnSignup=findViewById(R.id.btnSignup);

        btnSignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                User Usersignup= new User(Fullname.getText().toString(),
               Username.getText().toString(),
                        Contact.getText().toString(),
                        Email.getText().toString(),
                Password.getText().toString());


                EgiftAPI signUp= Url.getInstance().create(EgiftAPI.class);
                Call<Void> sign=signUp.signup(Usersignup);
                sign.enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if(!response.isSuccessful())
                        {
                            Toast.makeText(SignupActivity.this, "Code ", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        Intent signupSucess= new Intent(SignupActivity.this,MainActivity.class);
                        startActivity(signupSucess);

                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        Toast.makeText(SignupActivity.this, "Error" + t.getLocalizedMessage() , Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });



    }


    }

