package com.anish.egiftcards.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.anish.egiftcards.Acitivity.BuyGiftActivity;
import com.anish.egiftcards.Model.Gift;
import com.anish.egiftcards.R;
import com.anish.egiftcards.Url;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Gifts extends RecyclerView.Adapter<Gifts.hotelViewHolder> {
    private List<Gift> giftList;
    private Context mcontext;


    public Gifts( Context mcontext, List<Gift> giftList){

        this.giftList = giftList;
        this.mcontext=mcontext;

    }


    @NonNull
    @Override
    public hotelViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.activity_giftcardview, parent, false);
        return new hotelViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull hotelViewHolder holder, int i) {

        final Gift features = giftList.get (i);
        holder.giftName.setText(features.getGiftName());
        holder.giftPrice.setText(features.getGiftPrice());


        String imgPath = Url.imagePath +  features.getGiftPic();

        Picasso.get().load(imgPath).into(holder.imgGift);

        holder.imgGift.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent notify=new Intent(mcontext, BuyGiftActivity.class);

                notify.putExtra("id", features.get_id());
                notify.putExtra("giftName",features.getGiftName());
                notify .putExtra("giftPrice",features.getGiftPrice());
                notify.putExtra("giftImg",features.getGiftPic());
                mcontext.startActivity(notify);
            }
        });



    }

    @Override
    public int getItemCount() {
        return giftList.size();
    }

    public class hotelViewHolder extends RecyclerView.ViewHolder{

        TextView giftName,giftPrice;
         ImageView imgGift;


        public hotelViewHolder (@NonNull View itemView){
            super (itemView);

            giftName = itemView.findViewById(R.id.tvGiftname);
            giftPrice=itemView.findViewById(R.id.tvGiftprice);
            imgGift=itemView.findViewById(R.id.imgGift);


        }
    }

}
