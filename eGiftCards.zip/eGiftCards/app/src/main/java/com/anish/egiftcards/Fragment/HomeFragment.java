package com.anish.egiftcards.Fragment;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.anish.egiftcards.API.EgiftAPI;
import com.anish.egiftcards.Adapter.Gifts;
import com.anish.egiftcards.Model.Gift;
import com.anish.egiftcards.R;
import com.anish.egiftcards.Url;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {


private RecyclerView rcGifts;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view  = inflater.inflate(R.layout.fragment_home, container, false);

        rcGifts =view.findViewById(R.id.rcGifts);
        loadgifts();



        return view;
    }

    private void loadgifts() {

        EgiftAPI hotelAPI = Url.getInstance().create(EgiftAPI.class);
        Call<List<Gift>> hotelCall = hotelAPI.getgifts();

        hotelCall.enqueue(new Callback<List<Gift>>() {
            @Override
            public void onResponse(Call<List<Gift>> call, Response<List<Gift>> response) {
                if(!response.isSuccessful()){
                    Toast.makeText(getContext(), "Errror", Toast.LENGTH_SHORT).show();
                    return;
                }

                List<Gift> giftList = response.body();
                for (Gift gifts : giftList){
//                    String content = "";
//                    content+= "name:" + hotels.getHotelname() + "\n";
//                    content+= "city:" + hotels.getAddressCity() + "\n";
//                    content+= "district:" + hotels.getAddressDistrict() + "\n";
//                    content+= "price:" + hotels.getPrice() + "\n";
//                    content+= "available" + hotels.getAvailable() + "\n";


                    Gifts ha = new Gifts (getContext(), giftList);
                    rcGifts.setAdapter(ha);
                    rcGifts.setLayoutManager(new GridLayoutManager(getContext(),2));

                }

            }

            @Override
            public void onFailure(Call<List<Gift>> call, Throwable t) {

            }
        });

    }
}