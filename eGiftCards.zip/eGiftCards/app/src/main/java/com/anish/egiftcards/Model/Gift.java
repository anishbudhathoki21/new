package com.anish.egiftcards.Model;

public class Gift {



    private String giftName,giftPrice,giftPic;
    private String _id;

    public Gift(String giftName, String giftPrice, String giftPic, String _id) {
        this.giftName = giftName;
        this.giftPrice = giftPrice;
        this.giftPic = giftPic;
        this._id = _id;
    }

    public Gift(String giftName, String giftPrice, String giftPic) {
        this.giftName = giftName;
        this.giftPrice = giftPrice;
        this.giftPic = giftPic;
    }



    public String get_id() {
        return _id;
    }

    public void set_id(String _id) {
        this._id = _id;
    }

    public String getGiftName() {
        return giftName;
    }

    public void setGiftName(String giftName) {
        this.giftName = giftName;
    }

    public String getGiftPrice() {
        return giftPrice;
    }

    public void setGiftPrice(String giftPrice) {
        this.giftPrice = giftPrice;
    }

    public String getGiftPic() {
        return giftPic;
    }

    public void setGiftPic(String giftPic) {
        this.giftPic = giftPic;
    }
}
