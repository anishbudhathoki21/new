1. Title of your project

e-Gift Cards

2. Introduction

e-Gift cards application helps to find different types of gift cards and send them to the people they want. There are varieties of gift cards the user can select.This application is build using java and in the backend Node Js has been used .



3. Features of your project

	•User Registration and login.
	•Sending Gifts
	.Notification.
	•Searching
	
	
	
4. Android project Youtube video link
https://youtu.be/K-r6PN89H80


5. API link 
https://github.com/softwarica-github/t2-backend-api-anishbudhathoki21



6. REST client : Explain about retrofit and its uses 

Retrofit is a type-safe HTTP client for Android and Java developed by Square. Using Retrofit we can easily translate the REST APIs to Java Interfaces. Retrofit can be used as the best alternative to Volley. Retrofit Uses OkHttp for making HTTP requests. Retrofit easily translates JSON or XML response to POJO’s (Plain Old Java Objects).
Retrofit is a REST Client for Java and Android. It makes it relatively easy to retrieve and upload JSON (or other structured data) via a REST based web service. In Retrofit you configure which converter is used for the data serialization.

By the use of retrofit, networking is easier in Android apps. As it has many features like easy to add custom headers and request types, file uploads, mocking responses, etc through which we can reduce boilerplate code in our apps and consume the web service easily.

To work with Retrofit we basically need the following three classes:
1.A model class which is used as a JSON model.
2.An interface that defines the HTTP operations needs to be performed. 3.Retrofit.Builder class: Instance which uses the interface defined above and the Builder API to allow defining the URL endpoint for the HTTP operations. It also takes the converters we provide to format the Response.
